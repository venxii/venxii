Free for personal and commercial use

Bantayog is a rough, display typeface based on the characters repainted over the worn-out, cast iron text about significant events in the past and the lives of prominent national figures narrated on Philippine historical markers.

Share with your friends or donate to support my work https://gum.co/bantayog

More fonts at gumroad.com/johndavidmaza

https://www.behance.net/johndavidmaza